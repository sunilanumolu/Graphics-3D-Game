#include "main.h"


const color_t COLOR_RED = { 237, 27, 36 };
const color_t COLOR_DARKRED = { 164, 0, 0 };
const color_t COLOR_LIGHTRED = { 64, 0, 0 };
const color_t COLOR_GREY = { 127, 129, 126 };
const color_t COLOR_GREEN = { 34, 177, 77 };
const color_t COLOR_BLACK = { 0, 0, 0 };
const color_t COLOR_BROWN = { 185, 122, 87 };
const color_t COLOR_YELLOW = { 255, 242, 0 };
const color_t COLOR_BLUE = { 0, 164, 229 };
const color_t COLOR_PURPLE = { 152, 0, 220 };
const color_t COLOR_BACKGROUND = { 242, 241, 239 };
const color_t COLOR_CRIMSON = {220,20,60};
const color_t COLOR_PERU = {205, 133, 63};
const color_t COLOR_NAVAJO_WHITE = {255,222,173};
const color_t COLOR_SKIN = {255, 205, 148};
const color_t COLOR_NAVY = {0, 0, 128};
const color_t COLOR_GOLD = {255, 215, 0};
const color_t COLOR_LAWNGREEN = {124, 252, 0};
const color_t COLOR_AQUA = {0, 255, 255};
const color_t COLOR_AQUAMARINE = {127, 255, 212};
const color_t COLOR_MAGENTA = {255, 0, 255};
const color_t COLOR_SEAGREEN = {46, 139, 87};
const color_t COLOR_CHOCOLATE = {210, 105, 30};


#include "main.h"

#ifndef MISSILE_H
#define MISSILE_H


class Missile {
public:
    Missile() {}
    Missile(float x, float y, float z, float l, float r, glm::vec3 angles, color_t color);
    glm::vec3 position;
    float rotationx;
    float rotationy;
    float rotationz;
    float length;
    float radius;
    void draw(glm::mat4 VP);
    void set_position(float x, float y, float z);
    void tick();
    double speed;
private:
    VAO *object1;
    VAO *object2;
    VAO *object3;
    VAO *object;
};

#endif // MISSILE_H

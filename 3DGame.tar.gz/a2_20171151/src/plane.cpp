#include "plane.h"
#include "main.h"

Plane::Plane(float x, float y, float z, float l, float r, color_t color) {
    this->position = glm::vec3(x, y, z);
    this->rotationx = 0;
    this->rotationy = 0;
    this->rotationz = 0;

    //speed = 1;
    // Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    this->length = l;
    this->radius = r;
    GLfloat vertex_buffer_data1[22000];
    GLfloat vertex_buffer_data2[11000];
    GLfloat vertex_buffer_data3[11000];
    GLfloat vertex_buffer_data4[]={
        r, 0, 0,
        r, 0, 0.8,
        r+0.8, 0, 0.8,
        -r, 0, 0,
        -r, 0, 0.8,
        -r-0.8, 0, 0.8,
        r, 0, l,
        r, 0, l-0.5,
        r+0.6, 0, l-0.5,
        -r, 0, l,
        -r, 0, l-0.5,
        -r-0.6, 0, l-0.5,

    };

    int index1=0, index2=0, index3=0, index4=0;
    int j;

    for(int i=0; i<=360; i++)
    {
        j=i+1;

        //cylinder
        vertex_buffer_data1[index1++] = r*cos(M_PI*i/180);
        vertex_buffer_data1[index1++] = r*sin(M_PI*i/180);
        vertex_buffer_data1[index1++] = 0;
        vertex_buffer_data1[index1++] = r*cos(M_PI*i/180);
        vertex_buffer_data1[index1++] = r*sin(M_PI*i/180);
        vertex_buffer_data1[index1++] = l;
        vertex_buffer_data1[index1++] = r*cos(M_PI*j/180);
        vertex_buffer_data1[index1++] = r*sin(M_PI*j/180);
        vertex_buffer_data1[index1++] = 0;
        vertex_buffer_data1[index1++] = r*cos(M_PI*j/180);
        vertex_buffer_data1[index1++] = r*sin(M_PI*j/180);
        vertex_buffer_data1[index1++] = 0;
        vertex_buffer_data1[index1++] = r*cos(M_PI*i/180);
        vertex_buffer_data1[index1++] = r*sin(M_PI*i/180);
        vertex_buffer_data1[index1++] = l;
        vertex_buffer_data1[index1++] = r*cos(M_PI*j/180);
        vertex_buffer_data1[index1++] = r*sin(M_PI*j/180);
        vertex_buffer_data1[index1++] = l;

        //cone
        vertex_buffer_data2[index2++] = r*cos(M_PI*i/180);
        vertex_buffer_data2[index2++] = r*sin(M_PI*i/180);
        vertex_buffer_data2[index2++] = 0;
        vertex_buffer_data2[index2++] = 0;
        vertex_buffer_data2[index2++] = 0;
        vertex_buffer_data2[index2++] = -l/3;
        vertex_buffer_data2[index2++] = r*cos(M_PI*j/180);
        vertex_buffer_data2[index2++] = r*sin(M_PI*j/180);
        vertex_buffer_data2[index2++] = 0;

        //back
        vertex_buffer_data3[index3++] = r*cos(M_PI*i/180);
        vertex_buffer_data3[index3++] = r*sin(M_PI*i/180);
        vertex_buffer_data3[index3++] = l;
        vertex_buffer_data3[index3++] = 0;
        vertex_buffer_data3[index3++] = 0;
        vertex_buffer_data3[index3++] = l;
        vertex_buffer_data3[index3++] = r*cos(M_PI*j/180);
        vertex_buffer_data3[index3++] = r*sin(M_PI*j/180);
        vertex_buffer_data3[index3++] = l;
    }


    this->object1 = create3DObject(GL_TRIANGLES, 360*3*2, vertex_buffer_data1, color, GL_FILL);
    this->object2 = create3DObject(GL_TRIANGLES, 360*3, vertex_buffer_data2, COLOR_DARKRED, GL_FILL);
    this->object3 = create3DObject(GL_TRIANGLES, 360*3, vertex_buffer_data3, COLOR_YELLOW, GL_FILL);
    this->object4 = create3DObject(GL_TRIANGLES, 4*3, vertex_buffer_data4, COLOR_LIGHTRED, GL_FILL);

}

void Plane::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    //glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(1, 0, 0));
    glm::mat4 rotatex    = glm::rotate((float) (this->rotationx * M_PI / 180.0f), glm::vec3(1, 0, 0));
    glm::mat4 rotatey    = glm::rotate((float) (this->rotationy * M_PI / 180.0f), glm::vec3(0, 1, 0));
    glm::mat4 rotatez    = glm::rotate((float) (this->rotationz * M_PI / 180.0f), glm::vec3(0, 0, 1));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotatey * rotatex * rotatez);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object1);
    draw3DObject(this->object2);
    draw3DObject(this->object3);
    draw3DObject(this->object4);
}

void Plane::set_position(float x, float y, float z) {
    this->position = glm::vec3(x, y, z);
}

void Plane::tick() {
    //this->rotation += 0;
    // this->position.x -= speed;
    // this->position.y -= speed;
}


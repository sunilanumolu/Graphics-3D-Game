#include "main.h"

#ifndef BULLET_H
#define BULLET_H


class Bullet {
public:
    Bullet() {}
    Bullet(float x, float y, float z, float l, float r, glm::vec3 angles, color_t color);
    glm::vec3 position;
    float rotationx;
    float rotationy;
    float rotationz;
    float length;
    float radius;
    void draw(glm::mat4 VP);
    void set_position(float x, float y, float z);
    void tick();
    double speed;
private:
    VAO *object1;
    VAO *object2;
    VAO *object3;
    //VAO *object4;
};

#endif // BULLET_H

#include "bomb.h"
#include "main.h"

Bomb::Bomb(float x, float y, float z, glm::vec3 angles, color_t color) {
    this->position = glm::vec3(x, y, z);
    //this->rotation = h;
    this->rotationx = angles.x;
    this->rotationy = angles.y;
    this->rotationz = angles.z;
    //this->height = h;
    speed = 1;
    // Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    // A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices
    GLfloat vertex_buffer_data[1500000];
    int index=0,k;
    float a,b,c;
    float r = 0.5;
    // this->vx=vx;
    // this->vy=vy;
    // this->float_speed=0.007;
    for(int i=0; i<360; i++)
    {
        for(int j=0; j<90; j++)
        {
            c=r*cos(M_PI*j/180);
            a=r*sin(M_PI*j/180)*cos(M_PI*i/180);
            b=r*sin(M_PI*j/180)*sin(M_PI*i/180);
            vertex_buffer_data[index++]=r*sin(M_PI*j/180)*cos(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=r*cos(M_PI*j/180);
            vertex_buffer_data[index++]=r*sin(M_PI*j/180)*sin(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
            k=j+1;
            c=r*cos(M_PI*k/180);
            a=r*sin(M_PI*k/180)*cos(M_PI*i/180);
            b=r*sin(M_PI*k/180)*sin(M_PI*i/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
        }
    }

    for(int i=0; i<360; i++)
    {
        for(int j=0; j<90; j++)
        {
            c=r*cos(M_PI*(j+1)/180);
            a=r*sin(M_PI*(j+1)/180)*cos(M_PI*(i+1)/180);
            b=r*sin(M_PI*(j+1)/180)*sin(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=r*sin(M_PI*j/180)*cos(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=r*cos(M_PI*j/180);
            vertex_buffer_data[index++]=r*sin(M_PI*j/180)*sin(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
            k=j+1;
            c=r*cos(M_PI*k/180);
            a=r*sin(M_PI*k/180)*cos(M_PI*i/180);
            b=r*sin(M_PI*k/180)*sin(M_PI*i/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
        }
    }

    for(int i=0; i<360; i++)
    {
        for(int j=0; j<90; j++)
        {
            c=-r*cos(M_PI*j/180);
            a=-r*sin(M_PI*j/180)*cos(M_PI*i/180);
            b=-r*sin(M_PI*j/180)*sin(M_PI*i/180);
            vertex_buffer_data[index++]=-r*sin(M_PI*j/180)*cos(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=-r*cos(M_PI*j/180);
            vertex_buffer_data[index++]=-r*sin(M_PI*j/180)*sin(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
            k=j+1;
            c=-r*cos(M_PI*k/180);
            a=-r*sin(M_PI*k/180)*cos(M_PI*i/180);
            b=-r*sin(M_PI*k/180)*sin(M_PI*i/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
        }
    }

    for(int i=0; i<360; i++)
    {
        for(int j=0; j<90; j++)
        {
            c=-r*cos(M_PI*(j+1)/180);
            a=-r*sin(M_PI*(j+1)/180)*cos(M_PI*(i+1)/180);
            b=-r*sin(M_PI*(j+1)/180)*sin(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=-r*sin(M_PI*j/180)*cos(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=-r*cos(M_PI*j/180);
            vertex_buffer_data[index++]=-r*sin(M_PI*j/180)*sin(M_PI*(i+1)/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
            k=j+1;
            c=-r*cos(M_PI*k/180);
            a=-r*sin(M_PI*k/180)*cos(M_PI*i/180);
            b=-r*sin(M_PI*k/180)*sin(M_PI*i/180);
            vertex_buffer_data[index++]=a;
            vertex_buffer_data[index++]=c;
            vertex_buffer_data[index++]=b;
        }
    }
    
    this->object = create3DObject(GL_TRIANGLES, 90*360*3*4, vertex_buffer_data, color, GL_FILL);
}

void Bomb::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    //glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(1, 0, 0));
    glm::mat4 rotatex    = glm::rotate((float) (this->rotationx * M_PI / 180.0f), glm::vec3(1, 0, 0));
    glm::mat4 rotatey    = glm::rotate((float) (this->rotationy * M_PI / 180.0f), glm::vec3(0, 1, 0));
    glm::mat4 rotatez    = glm::rotate((float) (this->rotationz * M_PI / 180.0f), glm::vec3(0, 0, 1));
    //glm::mat4 scale = glm::scale(glm::vec3(0.5, 0.5, 0.5));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotatey * rotatex * rotatez);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
}

void Bomb::set_position(float x, float y, float z) {
    this->position = glm::vec3(x, y, z);
}

void Bomb::tick() {
    //this->rotation += 0;
    // this->position.x -= speed;
    // this->position.y -= speed;
}


#include "main.h"

#ifndef INDICAT_H
#define INDICAT_H


class Indicat {
public:
    Indicat() {}
    Indicat(float x, float y, float z, color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y, float z);
    void tick();
    double speed;
private:
    VAO *object1;
    //VAO *object2;
    //VAO *object;
};

#endif // INDICAT_H

#include "main.h"

#ifndef DASHBOARD_H
#define DASHBOARD_H


class Dashboard {
public:
    Dashboard() {}
    Dashboard(float x, float y, float z, float h, color_t color);
    glm::vec3 position;
    float rotation;
    float height;
    void draw(glm::mat4 VP);
    void set_position(float x, float y, float z);
    void tick();
    void dec_h();
    void inc_h();
    void dec1_h();
    void inc1_h();
    double speed;
private:
    VAO *object1;
    VAO *object2;
    //VAO *object;
};

#endif // DASHBOARD_H

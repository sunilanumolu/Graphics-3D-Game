#include "compass.h"
#include "main.h"

Compass::Compass(float x, float y, float z, glm::vec3 angles, color_t color) {
    this->position = glm::vec3(x, y, z);
    this->rotationx = angles.x;
    this->rotationy = angles.y;
    this->rotationz = angles.z;
    speed = 1;
    // Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    GLfloat vertex_buffer_data[10000];

    float r = 1;
    float r1 = 0;
    int j = 0;
    int index = 0;
    for(int i=0; i<360; i++)
    {   
        j = i+1;
        vertex_buffer_data[index++] = r1*cos(M_PI*i/180);
        vertex_buffer_data[index++] = r1*sin(M_PI*i/180);
        vertex_buffer_data[index++] = 0;
        vertex_buffer_data[index++] = r*cos(M_PI*i/180);
        vertex_buffer_data[index++] = r*sin(M_PI*i/180);
        vertex_buffer_data[index++] = 0;
        vertex_buffer_data[index++] = r*cos(M_PI*j/180);
        vertex_buffer_data[index++] = r*sin(M_PI*j/180);
        vertex_buffer_data[index++] = 0;
    }

    GLfloat vertex_buffer_data1[] = {
        0, 0.6, 0,
        0.3, 0, 0,
        -0.3, 0, 0,
    };

    GLfloat vertex_buffer_data2[] = {
        0, -0.6, 0,
        0.3, 0, 0,
        -0.3, 0, 0,
    };

    this->object = create3DObject(GL_TRIANGLES, 360*3, vertex_buffer_data, COLOR_GREY, GL_FILL);
    this->object1 = create3DObject(GL_TRIANGLES, 3, vertex_buffer_data1, COLOR_RED, GL_FILL);
    this->object2 = create3DObject(GL_TRIANGLES, 3, vertex_buffer_data2, COLOR_BLACK, GL_FILL);
}

void Compass::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotatex    = glm::rotate((float) (this->rotationx * M_PI / 180.0f), glm::vec3(1, 0, 0));
    glm::mat4 rotatey    = glm::rotate((float) (this->rotationy * M_PI / 180.0f), glm::vec3(0, 1, 0));
    glm::mat4 rotatez    = glm::rotate((float) (this->rotationz * M_PI / 180.0f), glm::vec3(0, 0, 1));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotatey * rotatex * rotatez);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
    draw3DObject(this->object1);
    draw3DObject(this->object2);
}

void Compass::set_position(float x, float y, float z) {
    this->position = glm::vec3(x, y, z);
}

void Compass::tick() {
    //this->rotation += 5;
    // this->position.x -= speed;
    // this->position.y -= speed;
}


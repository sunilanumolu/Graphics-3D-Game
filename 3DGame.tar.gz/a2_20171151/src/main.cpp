#include "main.h"
#include "timer.h"
#include "ball.h"
#include "plane.h"
#include "board.h"
#include "ring.h"
#include "arrow.h"
#include "island.h"
#include "bonus.h"
#include "petrol.h"
#include "bullet.h"
#include "cone.h"
#include "enemy.h"
#include "dashboard.h"
#include "bomb.h"
#include "canon.h"
#include "missile.h"
#include "compass.h"
#include "indicate.h"
#include "indicat.h"
#include "stop.h"

using namespace std;

GLMatrices Matrices;
GLuint     programID;
GLFWwindow *window;

/**************************
* Customizable functions *
**************************/

Plane Player;
Board Platform;
vector<Ring> rings;
vector<Arrow> arrows;
vector<Island> islands;
vector<Cone> valcanoes;
vector<Bonus> bonusR;
vector<Petrol> petrols;
vector<Bullet> bullets;
vector<Missile> missiles;
vector<Enemy> enemies;
vector<Bomb> bombs;
vector<Bomb> kills;
vector<Canon> canons;


Compass direction;
Dashboard status1;
Dashboard status2;
Indicate what;
Indicat what1;
Stop fin;

char title[1000];
float fuel=100;
float screen_zoom = 1, screen_center_x = 0, screen_center_y = 0;
float camera_rotation_angle = 0;
float Eye1, Eye2, Eye3;
int count = 0;
float u,v,n;
float u1,v1,n1;
int points = 0;
float health = 100;
int check = 0;
int cam = 1;
float rev = 0.3;
float theta=0;
int start = 0;
float z = 50.0f;
float rotate_vertical = 0;
float rotate_horizontal = 0;
int flager=0;
float st_x, st_y;
double xpos, ypos;
glm::mat4 projection1,projection2,projection3;

glm::vec3 eye;
glm::vec3 target;
glm::vec3 up;

Timer t60(1.0 / 60);

/* Render the scene with openGL */
/* Edit this function according to your assignment */
void draw() {
    // clear the color and depth in the frame buffer
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // use the loaded shader program
    // Don't change unless you know what you are doing
    glUseProgram (programID);

    // Eye - Location of camera. Don't change unless you are sure!!
    //glm::vec3 eye ( Player.position.x , Player.position.y + 9, Player.position.z + 9 );
    //glm::vec3 eye ( Eye1, Eye2, Eye3 );
    // Target - Where is the camera looking at.  Don't change unless you are sure!!
    //glm::vec3 target = Player.position;
    // Up - Up vector defines tilt of camera.  Don't change unless you are sure!!
    //glm::vec3 up (0, 1, 0);

    switch(cam){
    	case 1:
    	eye = glm::vec3( Player.position.x , Player.position.y + 9, Player.position.z + 9 );
    	target = Player.position;
    	up = glm::vec3(0, 1, 0);
    	break;
    	case 2:
    	eye = glm::vec3( Player.position.x , Player.position.y + 40, Player.position.z +0.1f);
    	target = Player.position;
    	up = glm::vec3(0, 1, 0);
    	break;
    	case 3:
    	eye = glm::vec3( 20 , 10, -20 );
    	target = Player.position;
    	up = glm::vec3(0, 1, 0);
    	break;
    	case 4:
    	eye = glm::vec3( Player.position.x -1.5f * sin(Player.rotationy * M_PI / 180.0f), Player.position.y, Player.position.z - 1.5f * cos(Player.rotationy * M_PI / 180.0f));
    	target = glm::vec3( Player.position.x - 2.5f * sin(Player.rotationy * M_PI / 180.0f), Player.position.y, Player.position.z - 2.5f * cos(Player.rotationy * M_PI / 180.0f));
    	// target = Player.position;
    	up = glm::vec3(0, 1, 0);
    	break;
    	case 5:
    	// eye = glm::vec3( Player.position.x , Player.position.y, Player.position.z - 1.5f);
    	// target = glm::vec3( Player.position.x  , Player.position.y, Player.position.z - 2.5f);
    	// // target = Player.position;
    	// up = glm::vec3(0, 1, 0);
    	// break;
    	glfwGetCursorPos(window, &xpos, &ypos);
            // cout << "Cursor Position at " << xpos << " : " << ypos << endl;
            if(ypos < 100)
            {
                rotate_vertical += 0.25f;
            }
            if(ypos > 500)
            {
                rotate_vertical -= 0.25f;
            }
            if(xpos > 500)
            {
                rotate_horizontal += 0.25f;
            }
            if(xpos < 100)
            {
                rotate_horizontal -= 0.25f;
            }
            eye = glm::vec3(Player.position.x + 7.0f * sin(rotate_horizontal * M_PI / 180.0f) * cos(rotate_vertical * M_PI / 180.0f),
                            Player.position.y + 7.0f * sin(rotate_vertical * M_PI / 180.0f),
                            Player.position.z + (7.0f * cos(rotate_horizontal * M_PI / 180.0f) * cos(rotate_vertical * M_PI / 180.0f)));
            // printf("%f %f %f\n", eye.x, eye.y, eye.z);
            target = glm::vec3(Player.position.x, Player.position.y, Player.position.z);
            up = glm::vec3(0, 1, 0);
            reset_screen();
            break;
    }

    // Compute Camera matrix (view)
    Matrices.view = glm::lookAt( eye, target, up ); // Rotating Camera for 3D
    // Don't change unless you are sure!!
    //Matrices.view = glm::lookAt(glm::vec3(0, 9, 9), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0)); // Fixed camera for 2D (ortho) in XY plane

    // Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
    // Don't change unless you are sure!!
    glm::mat4 VP = Matrices.projection * Matrices.view;

    glm::mat4 view1 = glm::lookAt(glm::vec3(0, 0, 4), glm::vec3(0, 0, 0), up);
    glm::mat4 VP1 = projection1 * view1;

    glm::mat4 view2 = glm::lookAt(glm::vec3(0, 0, 4), glm::vec3(0, 0, 0), up);
    glm::mat4 VP2 = projection2 * view2;

    glm::mat4 view3 = glm::lookAt(glm::vec3(0, 0, 4), glm::vec3(0, 0, 0), up);
    glm::mat4 VP3 = projection3 * view3;

    // Send our transformation to the currently bound shader, in the "MVP" uniform
    // For each model you render, since the MVP will be different (at least the M part)
    // Don't change unless you are sure!!
    glm::mat4 MVP;  // MVP = Projection * View * Model

    // Scene render
    Player.draw(VP);
    Platform.draw(VP);
    fin.draw(VP);

    for(int i=0; i<rings.size(); i++){
        rings[i].draw(VP);        
    }
    for(int i=0; i<arrows.size(); i++){
        arrows[i].draw(VP);        
    }
    for(int i=0; i<islands.size(); i++){
        islands[i].draw(VP);        
    }
    for(int i=0; i<bonusR.size(); i++){
        bonusR[i].draw(VP);        
    }
    for(int i=0; i<petrols.size(); i++){
        petrols[i].draw(VP);        
    }
    for(int i=0; i<bullets.size(); i++){
        bullets[i].draw(VP);        
    }
    for(int i=0; i<missiles.size(); i++){
        missiles[i].draw(VP);        
    }
    for(int i=0; i<bombs.size(); i++){
        bombs[i].draw(VP);        
    }
    for(int i=0; i<kills.size(); i++){
        kills[i].draw(VP);        
    }
    // for(int i=0; i<valcanoes.size(); i++){
    //     valcanoes[i].draw(VP);        
    // }
    for(int i=0; i<enemies.size(); i++){
        enemies[i].draw(VP);        
    }
    if(check == 0){
	    for(int i=0; i<canons.size(); i++){
	        canons[i].draw(VP);        
	    }
	}    

    count++;
    if(count%300 == 0)
    {
	    float x1,x2,y1,y2,z1,z2,x3,y3,z3;
	    x1 = Player.position.x; y1 = Player.position.y; z1 = Player.position.z;
	    x2 = canons[0].position.x; y2 = canons[0].position.y; z2 = canons[0].position.z;
	    x3 = enemies[0].position.x; y3 = enemies[0].position.y; z3 = enemies[0].position.z;

	    float r = sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2));
	    float r1 = sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3)+(z1-z3)*(z1-z3));
	    u = (x1-x2)/r;
	    v = (y1-y2)/r;
	    n = (z1-z2)/r;

	    u1 = (x1-x3)/r1;
	    v1 = (y1-y3)/r1;
	    n1 = (z1-z3)/r1;

	    float ang_x,ang_y,ang_z;
	    ang_x = acos(u); ang_y = acos(v); ang_z = acos(n);
	    //printf("%f %f %f\n",ang_x,ang_y,ang_z);
	    
    
    	missiles.push_back(Missile(canons[0].position.x, canons[0].position.y, canons[0].position.z, 1, 0.3,
    	glm::vec3(ang_x, ang_y, ang_z), COLOR_LAWNGREEN));

    	kills.push_back(Bomb(enemies[0].position.x, enemies[0].position.y, enemies[0].position.z, 
    		glm::vec3(Player.rotationx, Player.rotationy, Player.rotationz), COLOR_LIGHTRED));
	}


    glViewport(0, 0, (GLsizei) 50, (GLsizei) 400);    
    status1.draw(VP1);
    what.draw(VP1);
    glViewport(380, 0, (GLsizei) 385, (GLsizei) 400); 
    status2.draw(VP2);
    what1.draw(VP2);
    glViewport(0, 0, (GLsizei) 150, (GLsizei) 150); 
    direction.draw(VP3);
    glViewport (0, 0, (GLsizei) 600, (GLsizei) 600);

    if(flager==1){
    		theta+=3;
    		//printf("%f\n", theta);
    		Player.position.x  += rev*cos(glm::radians(theta));
    		Player.position.y  +=  rev*sin(glm::radians(theta));
    		// Player.position.z += 0;
    		if(theta >= 360){
    			flager = 0;
    			theta = 0;
    		}
    }

}

void tick_input(GLFWwindow *window) {
    int left  = glfwGetKey(window, GLFW_KEY_LEFT);
    int right = glfwGetKey(window, GLFW_KEY_RIGHT);
    int up  = glfwGetKey(window, GLFW_KEY_UP);
    int down  = glfwGetKey(window, GLFW_KEY_DOWN);
    int rolll = glfwGetKey(window, GLFW_KEY_A);
    int rollr = glfwGetKey(window, GLFW_KEY_D);
    int yawl = glfwGetKey(window, GLFW_KEY_Q);
    int yawr = glfwGetKey(window, GLFW_KEY_E);
    int pitchl = glfwGetKey(window, GLFW_KEY_Z);
    int pitchr = glfwGetKey(window, GLFW_KEY_X);
    int move = glfwGetKey(window, GLFW_KEY_W);
    int F1 = glfwGetKey(window, GLFW_KEY_1);
    int F2 = glfwGetKey(window, GLFW_KEY_2);
    int F3 = glfwGetKey(window, GLFW_KEY_3);
    int F4 = glfwGetKey(window, GLFW_KEY_4);
    int F5 = glfwGetKey(window, GLFW_KEY_5);
    // int R = glfwGetKey(window, GLFW_KEY_O);

    // if(R){ 
    	// flager=1;
    	// st_x = Player.position.x;
    	// st_y = Player.position.y;
    // }

    if(F1){ cam = 1; }
    if(F2){ cam = 2; }
    if(F3){ cam = 3; }
    if(F4){ cam = 4; }
    if(F5){ cam = 5; }

    if(move){//W
    	if(Player.position.z > -350){
        	Player.position.z -= 0.3*cos(M_PI*Player.rotationy/180);
        	Player.position.x -= 0.3*sin(M_PI*Player.rotationy/180);
    	}
        //fuel -= 0.1;
        //printf("chg/n");
    }
    
    if(up){
        Player.position.y += 0.1;
        status2.inc_h();
        //sprintf(title, "SuniRIde::PositionY : %f     Fuel : %d percent", Player.position.y, fuel);
    }
    if(down){
        Player.position.y -= 0.1;
        status2.dec_h();
        //sprintf(title, "SuniRIde::PositionY : %f     Fuel : %d percent", Player.position.y, fuel);
    }

    if(rollr){//D
        Player.rotationy -= 0.8;
        direction.rotationz -= 0.8;
        //printf("D%f\n", Player.rotationy);
    }else if(rolll){//A
        Player.rotationy += 0.8;
        direction.rotationz += 0.8;
        //printf("A%f\n", Player.rotationy);
    }

    if(yawr){//E
        Player.rotationz -= 1;
    }else if(yawl){//Q
        Player.rotationz += 1;
    }

    if(pitchr){//X
        Player.rotationx += 0.5;
    }else if(pitchl){//Z
        Player.rotationx -= 0.5;
    }


}

void tick_elements() {
    //ball1.tick();
    Eye1 = Player.position.x + 9*sin(M_PI * Player.rotationy/180);
    Eye2 = Player.position.y + 9;
    Eye3 = Player.position.z + 9*cos(M_PI * Player.rotationy/180);

    camera_rotation_angle += 0;
    for(int i=0; i<arrows.size(); i++){
        arrows[i].tick();        
    }
    for(int i=0; i<bonusR.size(); i++){
        bonusR[i].tick();        
    }

    vector<Bullet>::iterator fire;
    for(fire = bullets.begin(); fire != bullets.end(); fire++){
            fire->position.z -= 0.6*cos(M_PI*fire->rotationy/180);
            fire->position.x -= 0.6*sin(M_PI*fire->rotationy/180);
    }

    vector<Bomb>::iterator fire1;
    for(fire1 = bombs.begin(); fire1 != bombs.end(); fire1++){
            fire1->position.z -= 0.6*cos(M_PI*fire1->rotationy/180);
            fire1->position.x -= 0.6*sin(M_PI*fire1->rotationy/180);
    }

    vector<Missile>::iterator fire2;
    for(fire2 = missiles.begin(); fire2 != missiles.end(); fire2++){
            fire2->position.x += 0.3*u;
            fire2->position.y += 0.3*v;
            fire2->position.z += 0.3*n;     
    }

    vector<Bomb>::iterator fire3;
    for(fire3 = kills.begin(); fire3 != kills.end(); fire3++){
            fire3->position.x += 0.3*u1;
            fire3->position.y += 0.3*v1;
            fire3->position.z += 0.3*n1;     
    }

    bounding_box_t a;
    position_box b,c;
    b.x = Player.position.x;
    b.y = Player.position.y;
    b.z = Player.position.z;

    vector<Island>::iterator die;
    for(die = islands.begin(); die != islands.end(); die++){
	    a.min_x = die->position.x -10;
	    a.max_x = die->position.x +10;
	    a.min_y = die->position.y -10;
	    a.max_y = die->position.y +10;
	    a.min_z = die->position.z -10;
	    a.max_z = die->position.z +10;

	    if(detect_burn(a,b)){
	    	//exit(1);
	    }
	}

	vector<Ring>::iterator obj1;
	vector<Arrow>::iterator obj2;
	obj2 = arrows.begin();
    for(obj1 = rings.begin(); obj1 != rings.end(); obj1++){
	    a.min_x = obj1->position.x - 2;
	    a.max_x = obj1->position.x + 2;
	    a.min_y = obj1->position.y - 2;
	    a.max_y = obj1->position.y + 2;
	    a.min_z = obj1->position.z - 0.1;
	    a.max_z = obj1->position.z + 0.1;

	    if(detect_ring(a,b)){
	    	//exit(1);
	    	rings.erase(obj1);
	    	arrows.erase(obj2);
	    	points += 10;
	    	sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);
	    	break;
	    }
	    obj2++;
	}

	vector<Bonus>::iterator obj10;
    for(obj10 = bonusR.begin(); obj10 != bonusR.end(); obj10++){
	    a.min_x = obj10->position.x - 1;
	    a.max_x = obj10->position.x + 1;
	    a.min_y = obj10->position.y - 1;
	    a.max_y = obj10->position.y + 1;
	    a.min_z = obj10->position.z - 0.1;
	    a.max_z = obj10->position.z + 0.1;

	    if(detect_ring(a,b)){
	    	//exit(1);
	    	bonusR.erase(obj10);
	    	points += 50;
	    	sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);
	    	break;
	    }
	}

	vector<Petrol>::iterator obj11;
    for(obj11 = petrols.begin(); obj11 != petrols.end(); obj11++){
	    a.min_x = obj11->position.x - 1;
	    a.max_x = obj11->position.x + 1;
	    a.min_y = obj11->position.y - 1;
	    a.max_y = obj11->position.y + 1;
	    a.min_z = obj11->position.z - 0.5;
	    a.max_z = obj11->position.z + 0.5;

	    if(detect_ring(a,b)){
	    	//exit(1);
	    	petrols.erase(obj11);
	    	fuel += 50;
	    	
	    	break;
	    }
	}


	vector<Bullet>::iterator obj3;
	vector<Enemy>::iterator obj4;
	for(obj4 = enemies.begin(); obj4 != enemies.end(); obj4++){
	    a.min_x = obj4->position.x - 0.5;
	    a.max_x = obj4->position.x + 0.5;
	    a.min_y = obj4->position.y - 0.5;
	    a.max_y = obj4->position.y + 0.5;
	    a.min_z = obj4->position.z - 0.5;
	    a.max_z = obj4->position.z + 0.5;

	    for(obj3 = bullets.begin(); obj3 != bullets.end(); obj3++){
	    	c.x = obj3->position.x;
		    c.y = obj3->position.y;
		    c.z = obj3->position.z;

		    if(detect_ring(a,c)){
		    	//exit(1);
		    	enemies.erase(obj4);
		    	bullets.erase(obj3);
		    	points += 50;
		    	sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);
		    	break;
	    	}
	    }
	   
	}

	vector<Bomb>::iterator obj5;
	vector<Canon>::iterator obj6;
	for(obj6 = canons.begin(); obj6 != canons.end(); obj6++){
	    a.min_x = obj6->position.x - 1;
	    a.max_x = obj6->position.x + 1;
	    a.min_y = obj6->position.y - 1;
	    a.max_y = obj6->position.y + 1;
	    a.min_z = obj6->position.z - 1;
	    a.max_z = obj6->position.z + 1;

	    for(obj5 = bombs.begin(); obj5 != bombs.end(); obj5++){
	    	c.x = obj5->position.x;
		    c.y = obj5->position.y;
		    c.z = obj5->position.z;

		    if(detect_ring(a,c)){
		    	//exit(1);
		    	//canons.erase(obj6);
		    	bombs.erase(obj5);
		    	check = 1;
		    	points += 100;
		    	sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);
		    	break;
	    	}
	    }
	   
	}

	vector<Bomb>::iterator obj7;
    for(obj7 = kills.begin(); obj7 != kills.end(); obj7++){
	    a.min_x = Player.position.x - 0.3;
	    a.max_x = Player.position.x + 0.3;
	    a.min_y = Player.position.y - 0.3;
	    a.max_y = Player.position.y + 0.3;
	    a.min_z = Player.position.z - 0.3;
	    a.max_z = Player.position.z + 0.3;

	    c.x = obj7->position.x;
		c.y = obj7->position.y;
		c.z = obj7->position.z;

	    if(detect_ring(a,c)){
	    	health -= 25;
	    	sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);
	    	//exit(1);
	    }
	}

	vector<Missile>::iterator obj8;
    for(obj8 = missiles.begin(); obj8 != missiles.end(); obj8++){
	    a.min_x = Player.position.x - 0.3;
	    a.max_x = Player.position.x + 0.3;
	    a.min_y = Player.position.y - 0.3;
	    a.max_y = Player.position.y + 0.3;
	    a.min_z = Player.position.z - 0.3;
	    a.max_z = Player.position.z + 0.3;

	    c.x = obj8->position.x;
		c.y = obj8->position.y;
		c.z = obj8->position.z;

	    if(detect_ring(a,c)){
	    	health -= 25;
	    	sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);
	    	//exit(1);
	    }
	}


    glfwSetWindowTitle(window, title);
}

/* Initialize the OpenGL rendering properties */
/* Add all the models to be created here */
void initGL(GLFWwindow *window, int width, int height) {
    /* Objects should be created before any other gl function and shaders */
    // Create the models
    Player = Plane(0, 0, 20, 2.5, 0.5, COLOR_CRIMSON);
    Platform = Board(0, -150, 0, COLOR_BLUE);
    fin = Stop(0, 0, -350, COLOR_RED);
    islands.push_back(Island(-30, -58, -15, 2.5, COLOR_PURPLE));
    islands.push_back(Island(-30, -58, -55, 2.5, COLOR_PURPLE));
    islands.push_back(Island( 40, -58, -45, 2.5, COLOR_PURPLE));
    islands.push_back(Island(-50, -58, -100, 2.5, COLOR_PURPLE));
    islands.push_back(Island( 40, -58, -110, 2.5, COLOR_PURPLE));
    islands.push_back(Island( 40, -58, -150, 2.5, COLOR_PURPLE));
    islands.push_back(Island( -50, -58, -160, 2.5, COLOR_PURPLE));
    islands.push_back(Island( 40, -58, -200, 2.5, COLOR_PURPLE));
    islands.push_back(Island( -50, -58, -210, 2.5, COLOR_PURPLE));

    rings.push_back(Ring(0, 0, -10, 3, COLOR_GOLD));
    arrows.push_back(Arrow(0, 0, -5, 0, COLOR_AQUA));

    rings.push_back(Ring(6, 0, -40, 3, COLOR_GOLD));
    arrows.push_back(Arrow(3, 0, -25, -20, COLOR_AQUA));

    rings.push_back(Ring(-6, 0, -40, 3, COLOR_GOLD));
    arrows.push_back(Arrow(-3, 0, -25, 20, COLOR_AQUA));

    rings.push_back(Ring(6, 0, -80, 3, COLOR_GOLD));
    arrows.push_back(Arrow(3, 0, -60, -20, COLOR_AQUA));

    canons.push_back(Canon(10, 0, -50, COLOR_BLACK));

    bonusR.push_back(Bonus(0, 0, -60, 2, COLOR_LAWNGREEN));

    rings.push_back(Ring(-10, 0, -110, 3, COLOR_GOLD));
    arrows.push_back(Arrow(-3, 0, -90, 30, COLOR_AQUA));

    petrols.push_back(Petrol(-10, 0, -90, COLOR_RED));
    petrols.push_back(Petrol(10, 0, -200, COLOR_RED));
    //petrols.push_back(Petrol(0, 0, 0, COLOR_RED));

    enemies.push_back(Enemy(0, 0, -30, COLOR_PURPLE));
    enemies.push_back(Enemy(5, 0, -70, COLOR_PURPLE));
    enemies.push_back(Enemy(-8, 0, -120, COLOR_PURPLE));

    // bombs.push_back(Bomb(0, 0, 0, 0, COLOR_BLACK));
    // bombs.push_back(Bomb(0, 0, 0, 180, COLOR_BLACK));

    status1 = Dashboard(0, 0, 0, 10, COLOR_RED);
    what = Indicate(-1, -0.2, 0, COLOR_YELLOW);
    status2 = Dashboard(0, 0, 0, 5, COLOR_AQUA);
    what1 = Indicat(-1, -0.2, 0, COLOR_AQUA);
    direction = Compass(0, 0, 0, glm::vec3(Player.rotationx, Player.rotationy, Player.rotationz), COLOR_CRIMSON);

    // Create and compile our GLSL program from the shaders
    programID = LoadShaders("Sample_GL.vert", "Sample_GL.frag");
    // Get a handle for our "MVP" uniform
    Matrices.MatrixID = glGetUniformLocation(programID, "MVP");


    reshapeWindow (window, width, height);

    // Background color of the scene
    glClearColor (COLOR_BACKGROUND.r / 256.0, COLOR_BACKGROUND.g / 256.0, COLOR_BACKGROUND.b / 256.0, 0.0f); // R, G, B, A
    glClearDepth (1.0f);

    glEnable (GL_DEPTH_TEST);
    glDepthFunc (GL_LEQUAL);

    cout << "VENDOR: " << glGetString(GL_VENDOR) << endl;
    cout << "RENDERER: " << glGetString(GL_RENDERER) << endl;
    cout << "VERSION: " << glGetString(GL_VERSION) << endl;
    cout << "GLSL: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
}


int main(int argc, char **argv) {
    srand(time(0));
    int width  = 600;
    int height = 600;

    sprintf(title, "SunRIde::SCORE : %d     HEALTH : %f ", points, health);

    window = initGLFW(width, height);

    initGL (window, width, height);

    /* Draw in loop */
    while (!glfwWindowShouldClose(window)) {
        // Process timers

        if (t60.processTick()) {
            // 60 fps
            // OpenGL Draw commands
            // Eye1 = Player.position.x + 9*sin(M_PI * Player.rotationy/180);
            // Eye2 = Player.position.y + 9;
            // Eye3 = Player.position.z + 9*cos(M_PI * Player.rotationy/180);
            status1.dec1_h();
            //status2.dec_h();
            if(Player.position.y < -58){
                quit(window);
            }
            if(health <= 0){
            	//quit(window);
            }

            draw();
            //printf("%f %f %f\n", Eye1, Eye2, Eye3);
            // Swap Frame Buffer in double buffering
            glfwSwapBuffers(window);

            tick_elements();
            tick_input(window);
        }

        // Poll for Keyboard and mouse events
        glfwPollEvents();
    }

    quit(window);
}

// bool detect_collision(bounding_box_t a, bounding_box_t b) {
//     return (abs(a.x - b.x) * 2 < (a.width + b.width)) &&
//            (abs(a.y - b.y) * 2 < (a.height + b.height));
// }

bool detect_burn(bounding_box_t a, position_box b) {
	if(b.x > a.min_x -10 && b.x < a.max_x + 10){
		if(b.z > a.min_z -10 && b.z < a.max_z + 10){
			return true;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}

}

bool detect_ring(bounding_box_t a, position_box b) {
	if(b.x > a.min_x  && b.x < a.max_x ){
		if(b.y > a.min_y && b.y < a.max_y && b.z > a.min_z && b.z < a.max_z){
			return true;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}

}

void reset_screen() {
    float top    = screen_center_y + 4 / screen_zoom;
    float bottom = screen_center_y - 4 / screen_zoom;
    float left   = screen_center_x - 4 / screen_zoom;
    float right  = screen_center_x + 4 / screen_zoom;
    //Matrices.projection = glm::ortho(left, right, bottom, top, 0.1f, 500.0f);
    // Matrices.projection = glm::perspective(glm::radians(50.0f), 4.0f/3.0f, 0.1f, 100.0f);
    Matrices.projection = glm::perspective(glm::radians(z), 4.0f/3.0f, 0.1f, 100.0f);
    projection1 = glm::ortho(-3.0f, 3.0f, -1.0f, 1.0f, 0.1f, 500.0f);
    projection2 = glm::ortho(-18.0f, 18.0f, -1.0f, 1.0f, 0.1f, 500.0f);
    projection3 = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 500.0f);
}

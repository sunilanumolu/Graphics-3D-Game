#include "main.h"

#ifndef BONUS_H
#define BONUS_H


class Bonus {
public:
    Bonus() {}
    Bonus(float x, float y, float z, float r, color_t color);
    glm::vec3 position;
    float rotation;
    float radius;
    void draw(glm::mat4 VP);
    void set_position(float x, float y, float z);
    void tick();
    double speed;
private:
    VAO *object;
};

#endif // BONUS_H
